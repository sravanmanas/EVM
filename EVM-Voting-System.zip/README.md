# EVM Voting System — Mobile Electronic Voting Machine

A complete mobile-based EVM (Electronic Voting Machine) web application for school and college elections.

## Tech Stack
- React 18 + TypeScript + Vite
- Tailwind CSS v3 + shadcn/ui
- React Router DOM v6
- Sonner (toasts)
- JSZip (project export)

## Roles
1. **Election Officer** (Admin) — Login: `admin` / `0000` (changeable)
   - Create & manage multiple elections
   - Add candidates with party symbol images
   - Upload student ID lists (CSV)
   - Activate/End elections, view & share results
2. **Polling Officer** (Teacher) — Login with Election ID + Control PIN
   - PIN-locked EVM control for each voter
3. **Student** — Enter Student ID on the voting screen

## Getting Started
```bash
npm install
npm run dev
```

## Features
- Multiple elections (per class/department)
- Candidate party symbol image upload
- CSV student ID bulk import
- 4-digit PIN-locked EVM mode
- Anonymous vote recording
- Victory card generator with social sharing
- Dark/Light mode
- Full project export as ZIP
